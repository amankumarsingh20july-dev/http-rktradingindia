const express = require('express');
const router = express.Router();

// GET all suppliers
router.get('/', (req, res) => {
  req.db.all('SELECT * FROM suppliers ORDER BY company_name ASC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// POST add supplier
router.post('/', (req, res) => {
  const { company_name, contact_person, phone, email, address, gstin } = req.body;
  const sql = `INSERT INTO suppliers (company_name, contact_person, phone, email, address, gstin, outstanding_payable)
    VALUES (?, ?, ?, ?, ?, ?, 0)`;

  req.db.run(sql, [company_name, contact_person, phone, email, address, gstin], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    res.status(201).json({ id: this.lastID, message: 'Supplier added successfully' });
  });
});

module.exports = router;
