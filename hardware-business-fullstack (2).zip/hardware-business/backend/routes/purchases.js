const express = require('express');
const router = express.Router();

// GET all purchases
router.get('/', (req, res) => {
  req.db.all('SELECT * FROM purchases ORDER BY id DESC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// POST record new stock purchase from supplier
// Automatically adds stock quantities to products
router.post('/', (req, res) => {
  const {
    purchase_invoice_no, supplier_id, supplier_name, date,
    subtotal_taxable, total_tax, grand_total, paid_amount,
    due_amount, payment_status, payment_mode, items
  } = req.body;

  req.db.serialize(() => {
    req.db.run('BEGIN TRANSACTION');

    const insertPurchase = `INSERT INTO purchases 
      (purchase_invoice_no, supplier_id, supplier_name, date, subtotal_taxable, total_tax, grand_total, paid_amount, due_amount, payment_status, payment_mode)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    req.db.run(
      insertPurchase,
      [purchase_invoice_no, supplier_id, supplier_name, date, subtotal_taxable, total_tax, grand_total, paid_amount, due_amount, payment_status, payment_mode],
      function (err) {
        if (err) {
          req.db.run('ROLLBACK');
          return res.status(500).json({ error: err.message });
        }
        const purchaseId = this.lastID;

        const itemStmt = req.db.prepare(`INSERT INTO purchase_items 
          (purchase_id, product_id, product_name, quantity, unit, purchase_rate, taxable_amount, gst_rate, tax_amount, total_amount)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);

        const stockIncrementStmt = req.db.prepare(`UPDATE products SET current_stock = current_stock + ? WHERE id = ?`);

        items.forEach((item) => {
          itemStmt.run([
            purchaseId, item.productId, item.productName, item.quantity,
            item.unit, item.purchaseRate, item.taxableAmount, item.gstRate,
            item.taxAmount, item.totalAmount
          ]);
          stockIncrementStmt.run([item.quantity, item.productId]);
        });

        itemStmt.finalize();
        stockIncrementStmt.finalize();

        // Update supplier balance if balance due
        if (supplier_id && due_amount > 0) {
          req.db.run('UPDATE suppliers SET outstanding_payable = outstanding_payable + ? WHERE id = ?', [due_amount, supplier_id]);
        }

        req.db.run('COMMIT', (commitErr) => {
          if (commitErr) return res.status(500).json({ error: commitErr.message });
          res.status(201).json({ purchaseId, message: 'Stock received & inventory updated successfully' });
        });
      }
    );
  });
});

module.exports = router;
