const express = require('express');
const router = express.Router();

// GET all customers
router.get('/', (req, res) => {
  req.db.all('SELECT * FROM customers ORDER BY name ASC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// POST create customer
router.post('/', (req, res) => {
  const { name, business_name, phone, email, address, gstin, customer_type, credit_limit } = req.body;
  const sql = `INSERT INTO customers (name, business_name, phone, email, address, gstin, customer_type, credit_limit, outstanding_balance)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)`;

  req.db.run(sql, [name, business_name, phone, email, address, gstin, customer_type || 'Retail', credit_limit || 50000], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    res.status(201).json({ id: this.lastID, message: 'Customer registered successfully' });
  });
});

// GET customer ledger statement
router.get('/:id/ledger', (req, res) => {
  const { id } = req.params;
  const sql = `SELECT * FROM sales WHERE customer_id = ? ORDER BY date DESC`;
  req.db.all(sql, [id], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

module.exports = router;
