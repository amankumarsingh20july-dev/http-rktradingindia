const express = require('express');
const router = express.Router();

// GET all sales / invoices
router.get('/', (req, res) => {
  req.db.all('SELECT * FROM sales ORDER BY id DESC LIMIT 100', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// POST process new sale / POS invoice
// Automatically updates product stock levels and updates customer balance
router.post('/', (req, res) => {
  const {
    invoice_no, sale_type, customer_id, customer_name, customer_phone,
    customer_gstin, date, subtotal_taxable, total_cgst, total_sgst,
    total_igst, total_tax, discount, round_off, grand_total, payment_mode,
    paid_amount, due_amount, status, notes, items
  } = req.body;

  req.db.serialize(() => {
    req.db.run('BEGIN TRANSACTION');

    const insertSale = `INSERT INTO sales 
      (invoice_no, sale_type, customer_id, customer_name, customer_phone, customer_gstin, date, subtotal_taxable, total_cgst, total_sgst, total_igst, total_tax, discount, round_off, grand_total, payment_mode, paid_amount, due_amount, status, notes)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    req.db.run(
      insertSale,
      [invoice_no, sale_type, customer_id, customer_name, customer_phone, customer_gstin, date, subtotal_taxable, total_cgst, total_sgst, total_igst, total_tax, discount, round_off, grand_total, payment_mode, paid_amount, due_amount, status, notes],
      function (err) {
        if (err) {
          req.db.run('ROLLBACK');
          return res.status(500).json({ error: err.message });
        }
        const saleId = this.lastID;

        // Insert items and decrease stock
        const itemStmt = req.db.prepare(`INSERT INTO sale_items 
          (sale_id, product_id, product_name, sku, hsn_code, quantity, unit, rate, taxable_amount, gst_rate, cgst_amount, sgst_amount, igst_amount, total_amount)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);

        const stockUpdateStmt = req.db.prepare(`UPDATE products SET current_stock = current_stock - ? WHERE id = ?`);

        items.forEach((item) => {
          itemStmt.run([
            saleId, item.productId, item.productName, item.sku, item.hsnCode,
            item.quantity, item.unit, item.rate, item.taxableAmount, item.gstRate,
            item.cgstAmount, item.sgstAmount, item.igstAmount, item.totalAmount
          ]);
          stockUpdateStmt.run([item.quantity, item.productId]);
        });

        itemStmt.finalize();
        stockUpdateStmt.finalize();

        // If customer has credit due, update customer outstanding balance
        if (customer_id && due_amount > 0) {
          req.db.run('UPDATE customers SET outstanding_balance = outstanding_balance + ? WHERE id = ?', [due_amount, customer_id]);
        }

        req.db.run('COMMIT', (commitErr) => {
          if (commitErr) return res.status(500).json({ error: commitErr.message });
          res.status(201).json({ saleId, invoice_no, message: 'Sale recorded & stock deducted successfully' });
        });
      }
    );
  });
});

module.exports = router;
