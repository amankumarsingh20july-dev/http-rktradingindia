const express = require('express');
const router = express.Router();

// GET all products
router.get('/', (req, res) => {
  const { category, search, lowStock } = req.query;
  let query = 'SELECT * FROM products WHERE 1=1';
  const params = [];

  if (category) {
    query += ' AND category = ?';
    params.push(category);
  }
  if (search) {
    query += ' AND (name LIKE ? OR sku LIKE ? OR barcode LIKE ?)';
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }
  if (lowStock === 'true') {
    query += ' AND current_stock <= min_stock_alert';
  }
  query += ' ORDER BY name ASC';

  req.db.all(query, params, (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// GET single product by ID or Barcode
router.get('/:idOrBarcode', (req, res) => {
  const param = req.params.idOrBarcode;
  req.db.get(
    'SELECT * FROM products WHERE id = ? OR barcode = ? OR sku = ?',
    [param, param, param],
    (err, row) => {
      if (err) return res.status(500).json({ error: err.message });
      if (!row) return res.status(404).json({ error: 'Product not found' });
      res.json(row);
    }
  );
});

// POST create new product
router.post('/', (req, res) => {
  const {
    sku, barcode, name, category, unit, hsn_code,
    cost_price, wholesale_price, retail_price, gst_rate,
    current_stock, min_stock_alert, location_rack
  } = req.body;

  const sql = `INSERT INTO products 
    (sku, barcode, name, category, unit, hsn_code, cost_price, wholesale_price, retail_price, gst_rate, current_stock, min_stock_alert, location_rack)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

  req.db.run(
    sql,
    [sku, barcode, name, category, unit, hsn_code, cost_price, wholesale_price, retail_price, gst_rate || 18, current_stock || 0, min_stock_alert || 10, location_rack],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.status(201).json({ id: this.lastID, message: 'Product created successfully' });
    }
  );
});

// PUT update product
router.put('/:id', (req, res) => {
  const { id } = req.params;
  const {
    name, category, unit, hsn_code, cost_price, wholesale_price,
    retail_price, gst_rate, current_stock, min_stock_alert, location_rack
  } = req.body;

  const sql = `UPDATE products SET 
    name = ?, category = ?, unit = ?, hsn_code = ?, cost_price = ?,
    wholesale_price = ?, retail_price = ?, gst_rate = ?, current_stock = ?,
    min_stock_alert = ?, location_rack = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?`;

  req.db.run(
    sql,
    [name, category, unit, hsn_code, cost_price, wholesale_price, retail_price, gst_rate, current_stock, min_stock_alert, location_rack, id],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Product updated successfully' });
    }
  );
});

module.exports = router;
