/**
 * Hardware Business Management ERP - Main Server Entry Point
 */
const express = require('express');
const cors = require('cors');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve frontend static files
app.use(express.static(path.join(__dirname, '../frontend')));

// Initialize SQLite database
const dbPath = path.join(__dirname, 'database/hardware.db');
const dbDir = path.join(__dirname, 'database');
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Error connecting to database:', err.message);
  } else {
    console.log('Connected to SQLite database: hardware.db');
    // Execute database.sql to bootstrap tables if fresh
    const sqlScriptPath = path.join(__dirname, 'database/database.sql');
    if (fs.existsSync(sqlScriptPath)) {
      const sql = fs.readFileSync(sqlScriptPath, 'utf8');
      db.exec(sql, (execErr) => {
        if (execErr) console.warn('Database bootstrap warning:', execErr.message);
        else console.log('Database tables verified and ready.');
      });
    }
  }
});

// Pass database handle to requests
app.use((req, res, next) => {
  req.db = db;
  next();
});

// Mount API Routes
app.use('/api/products', require('./routes/products'));
app.use('/api/sales', require('./routes/sales'));
app.use('/api/purchases', require('./routes/purchases'));
app.use('/api/customers', require('./routes/customers'));
app.use('/api/suppliers', require('./routes/suppliers'));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

// Fallback to frontend index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Start server
app.listen(PORT, () => {
  console.log(`======================================================`);
  console.log(` R.K. TRADING ERP Server running on http://localhost:${PORT}`);
  console.log(` Satish Kedia & Shubham | Exhibition Road, Patna`);
  console.log(` POS, Inventory & Online Store API at http://localhost:${PORT}/api`);
  console.log(`======================================================`);
});
