# R.K. TRADING - Hardware & Modular Kitchen ERP System
**Owners:** Satish Kedia (Mob: 9431457263) & Shubham (Mob: 9798253950)
**Address:** Salimpur Ahra Road, Near Rajkumar Hotel, Pillar No. 16, Exhibition Road, Patna - 800 001
**Deals In:** Fancy Hardware, Profile, Bathroom Fitting, Modular Kitchen, Accessories, Ply, Mica etc.
**Brands:** STARRS Premium Hardware, Hardwyn, Godrej, Link Locks

Complete, production-ready Full-Stack Hardware ERP System with high-speed POS billing, GST tax invoicing, automatic stock tracking, supplier/customer khata ledger, daily daybook, GSTR-1 reports, and retail/wholesale online storefront with UPI payments.

## 📁 Project Structure

```text
hardware-business/
│
├── frontend/
│   ├── index.html       # Admin Dashboard & Login
│   ├── products.html    # Product & Stock Management
│   ├── sales.html       # POS Billing & GST Invoices
│   ├── purchase.html    # Stock Purchase & Inward Bills
│   ├── customers.html   # Customer Directory & Khata
│   ├── suppliers.html   # Supplier Directory & Payables
│   ├── payments.html    # Receipts & Payment Vouchers
│   ├── expenses.html    # Shop Operating Expenses
│   ├── ledger.html      # Account Statements & Daybook
│   ├── reports.html     # GST (GSTR-1), P&L, Sales & Stock Reports
│   └── css/
│       └── style.css    # Clean responsive industrial styling
│
├── backend/
│   ├── server.js        # Express application entry point
│   ├── package.json     # Node dependencies
│   ├── routes/
│   │   ├── products.js  # Inventory & stock adjustment routes
│   │   ├── sales.js     # POS, billing, and GST invoice generation
│   │   ├── purchases.js # Stock inward and supplier billing
│   │   ├── customers.js # Customer accounts and ledger
│   │   └── suppliers.js # Supplier accounts and dues
│   └── database/
│       └── database.sql # Complete SQL schema with tables & seeds
│
└── README.md
```

## 🚀 Quick Start Instructions

### Prerequisites
- Node.js (version 16 or newer)
- SQLite3 or MySQL/MariaDB (default database script runs on SQLite3 out-of-the-box, compatible with PostgreSQL/MySQL)

### Step 1: Install Dependencies
Open your terminal in the `backend` directory:
```bash
cd backend
npm install
```

### Step 2: Initialize Database
The backend automatically creates and seeds `hardware.db` on the first startup using `database/database.sql`.
Or manually run the SQL script in your database client:
```bash
sqlite3 database/hardware.db < database/database.sql
```

### Step 3: Start the Backend Server
```bash
npm start
```
The server will boot on `http://localhost:5000`.

### Step 4: Open Frontend
Navigate to `frontend/` and simply open `index.html` in your browser, or access `http://localhost:5000` as the server automatically serves the frontend!

---

## 🔑 Default Credentials
- **Username:** `admin`
- **Password:** `admin123`

## 📦 Features Included
1. **Automatic Stock Calculation**: Every sale deducts stock; every purchase adds stock; manual adjustments logged in `stock_ledger`.
2. **GST Invoicing**: Automatic CGST, SGST, IGST breakdown, HSN codes, and print-ready tax invoice format.
3. **Wholesale vs Retail Pricing**: Toggle between wholesale rates for contractors and retail MRP for walk-ins.
4. **Customer & Supplier Khata**: Track credit limits, pending dues, debit/credit journal ledger.
5. **Daybook & Reports**: Daily cash flow, profit & loss, GSTR-1 summary, and stock valuation.
